﻿// © Sitecore Corporation A/S. All rights reserved. Sitecore® is a registered trademark of Sitecore Corporation A/S.

namespace Sitecore.Pages.E2EFramework.UI.Tests.ApiHelpers.EdgeGraphQL.Modals
{
    public class Field
    {
        public string name { get; set; }
        public string id { get; set; }
        public string value { get; set; }
        public string __typename { get; set; }
    }
}
