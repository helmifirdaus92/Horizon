﻿// © Sitecore Corporation A/S. All rights reserved. Sitecore® is a registered trademark of Sitecore Corporation A/S.

namespace Sitecore.Horizon.Integration.Tests.Unit
{
    internal static class TestCollections
    {
        public const string HttpContext = "HttpContext.Current";
    }
}
